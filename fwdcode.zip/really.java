import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
 
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.util.Base64;
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileReader; 
 import java.io.FileOutputStream;  
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Scanner;
 
public class really {
 
    private static SecretKeySpec secretKey;
    private static byte[] key;
 
    public static void setKey(String myKey)
    {
        MessageDigest sha = null;
        try {
            key = myKey.getBytes("UTF-8");
            sha = MessageDigest.getInstance("SHA-1");
            key = sha.digest(key);
            key = Arrays.copyOf(key, 16);
            secretKey = new SecretKeySpec(key, "AES");
        }
        catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }
 
    public static String decrypt(String strToDecrypt, String secret)
    {
        try
        {
            setKey(secret);
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
	    
            byte[] s=cipher.doFinal(Base64.getDecoder().decode(strToDecrypt));
	    String h=new String(s);
	   
	    BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\G50-70\\Downloads\\test.txt"));
    writer.write(h);
    writer.close();
            
        }
        catch (Exception e)
        {
            System.out.println("Error while decrypting: " + e.toString());
        }
        return null;
    }
 
    

public static void main(String[] args)
{

    String password = "harika";
        String inputPass;
        Scanner  inp = new Scanner(System.in);
         
        System.out.println("Enter Your Password:");
        inputPass = inp.nextLine();
 
        if (inputPass.equals(password)) {
    
    final String secretKey = "ssshhhhhhhhhhh!!!!";
    StringBuilder sb = new StringBuilder();
        String strLine = "";
        String originalString = "";
       String  inputFileName;
	Scanner user = new Scanner(System.in); 
    Scanner input = null;
    System.out.print("Input file name:");
    String fileName = user.next();
    File inputFile = new File(fileName);

        try {
             BufferedReader br = new BufferedReader(new FileReader(inputFile));
             while (strLine != null)
             {
                if (strLine == null)
                  break;
                originalString += strLine;
                strLine = br.readLine();
                
            }
              
             br.close();
        } catch (FileNotFoundException e) {
            System.err.println("File not found");
        } catch (IOException e) {
            System.err.println("Unable to read the file.");
        }
    
    //String encryptedString = AES1.encrypt(originalString, secretKey) ; 
    String decryptedString = really.decrypt(originalString, secretKey) ;
   // System.out.println(encryptedString);
    System.out.println(decryptedString);
    }
else{
	System.out.println("Wrong password");
}
}}